export const SET_VIDEO_DATA = 'SET_VIDEO_DATA';
