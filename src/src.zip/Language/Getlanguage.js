import AsyncStorage from '@react-native-async-storage/async-storage';

export const getlang = await AsyncStorage.getItem('Applang');



