export const API_URL = 'http://dev.codemeg.com/sayhello/api/';
export const GOOGLE_MAP_API = 'AIzaSyB7qa8Uk4xxkHnrV6mGUCJrte7g9WH_hPA';
// export const API_URL = 'http://192.168.1.23/sayhello/api/';