//import liraries
import React, { Component } from 'react';
import { View, Text, StyleSheet,ScrollView,Image } from 'react-native';

const Connectnotification = ({ navigation,route }) => {
    return (
        <View >
            <Text style={{color: 'blue',fontWeight: 'bold',fontSize: 30,}}>Connect notification</Text>
        </View>
    );
};
export default Connectnotification;