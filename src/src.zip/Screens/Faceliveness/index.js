//import liraries
import React, { Component } from 'react';
import { View, Text, } from 'react-native';

const Faceliveness = ({ navigation,route }) => {
    return (
        <View >
            <Text style={{color: 'blue',fontWeight: 'bold',fontSize: 30,}}>Face liveness</Text>
        </View>
    );
};
export default Faceliveness;